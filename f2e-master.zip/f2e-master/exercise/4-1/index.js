﻿//http://tw.somee.com/demo/4-1/data.ashx
$(function() {
    
});