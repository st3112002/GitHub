﻿$(function() {
	$(document).click(function() {
		$("#box").fadeOut();
	});
	$("#btn").click(function() {
		$("#box").fadeIn();
	});
	$("#box").click(function() {
		
	});
});