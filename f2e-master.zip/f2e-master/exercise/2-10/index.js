﻿$(function() {
    $("#test").click(function() {

        alert("您按下了" + $(this).val());
    });
});