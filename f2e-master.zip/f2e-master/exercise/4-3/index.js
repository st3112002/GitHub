﻿//http://tw.somee.com/demo/4-3/data.ashx
$(function() {
    
});