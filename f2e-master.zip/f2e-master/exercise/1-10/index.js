﻿$(function() {
    $(window).load(function() {
        $(".loading").delay(500).fadeOut();
    });
});