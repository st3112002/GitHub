﻿$(function() {
    $("#test").click(function() {
        debugger;
        alert("您按下了" + $(this).val());
    });
});