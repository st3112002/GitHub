﻿$(function () {
    var progress = 45;
    $(".bar").width(progress + "%");
});