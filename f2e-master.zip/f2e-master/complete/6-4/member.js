﻿$(function () {
    var name = "會員人數";
    var count = 57;
    $("ul").append("<li><a>" + name + "：" + count + "人</a></li>");
});