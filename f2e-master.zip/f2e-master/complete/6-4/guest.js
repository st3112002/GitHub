﻿$(function () {
    var name = "訪客人數";
    var count = 25;
    $("ul").append("<li><a>" + name + "：" + count + "人</a></li>");
});