﻿(function($) {
    $.fn.render = function(data) {
        var html = this.html();
        for (var key in data) {
            html = html.replace("{{" + key + "}}", data[key]);
        }
        this.html(html);
    };
})(jQuery);

$(function() {
    $(".box1").render({title:"網頁設計基本觀念",content:"所謂的HTML檔案基本上是一個單純的文字檔..."});
    $(".box2").render({title:"CSS語法結構",content:"CSS是指Cascading Style Sheets稱為層疊樣式表..."});
    $(".box3").render({title:"JavaScript程式設計",content:"JavaScript描述語言是一種網頁描述語言..."});
});
