﻿$(function () {
    $("#header").load("common.html #header>div");
    $("#footer").load("common.html #footer>div");
});