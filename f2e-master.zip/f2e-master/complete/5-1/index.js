﻿$(function() {
    $.getJSON("http://data.taipei.gov.tw/opendata/apply/json/QUYwMTIzQ0UtNDBEMi00ODA0LTg5RjMtMUQ0QkVCODAzRDIy", function(data) {
        //......
    });
});